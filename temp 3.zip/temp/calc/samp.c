#include<stdio.h>

int main()
{
	int a,b;
	a=b*2;
	printf("%d\n",a);
	return 0;
}